const button = document.getElementById('button');
const name = document.getElementById('selection');
const format = document.getElementById('format');
const price = document.getElementById('price');

const result = document.getElementById('result');

function deleteLastInput() {
  let list = document.getElementById('myList');
  list.removeChild(list.childNodes[list.childNodes.length - 1]);
}



const sales = () => {

  
  let result = document.getElementById('price').value;
    if (result != "") {
      let list = document.getElementById('myList');
      let item = document.createElement('li');
      item.innerHTML = `${name.value} -- ${format.value} -- ${result} R$`;
      list.appendChild(item);

  
      document.getElementById('price').value='';
    }

  

  const saleItem = name.value + format.value + price.value;
  result.textContent = `${name.value} - ${format.value} - ${price.value} Real`;
  console.log(saleItem)




}

button.addEventListener('click', sales);







































// //Uses a Function to create new items on the list!
// function createNewItem(sale) {
//     var newItem = document.createElement("li");
//     var newText = document.createTextNode(sale);
//     newItem.appendChild(newText);
//     var position = document.getElementsByTagName("ul")[0];
//     position.appendChild(newItem);
// }

// //sets variables for adding list items
// var userInput = document.getElementById("userInput");
// var submitButton = document.getElementById("submit");

// submitButton.addEventListener('click', function() {
//   var inputItem = userInput.value;
//   createNewItem(inputItem);
// }, false);

// //Next Steps
// //Set items as persistent
// //Enable item deletion
// //Double-click to change bg color/priority
// //Enable Moving items up & Down the list